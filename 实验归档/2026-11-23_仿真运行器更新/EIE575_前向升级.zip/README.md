# EIE575 仿真运行器前向更新

本版合并两项改动。正式登记前检查冻结配置及其 P3 凭据。真实运行把 1800 秒进度检查、初始预算和该请求的批准硬上限分别记录，可在同一 attempt 内使用已经批准的剩余额度。已有 P4 分层预算继续作为初始下限。预算细节在安装后的 `docs/wall_budget.md`。

升级清单 `release.json` 的 SHA-256 为 `6e198d32985abb589135f53dc050134a86313c66063b4a84450f195114cbb888`。清单列出 11 个安装文件、替换前后 SHA-256、全部科学源码指纹及原模拟器 SHA-256。两个原始补丁仍保留。安装器按清单使用与 Windows 工作树逐字节匹配的文件。

## 预检

在解压目录执行下列 PowerShell。请指定一个尚不存在的回执文件。

```powershell
$project = 'E:\Temp\eie575_tabr'
$cfg = Get-Content -Raw -LiteralPath (Join-Path $project 'configs\core.json') | ConvertFrom-Json
$python = $cfg.tools.analysis_python
$releaseSha = '6e198d32985abb589135f53dc050134a86313c66063b4a84450f195114cbb888'
& $python -B install.py check --target $project --release-sha256 $releaseSha --receipt $preflightReceipt
```

## 安装

归档负责人放行旧源码、宿主及两个指定 E0 回执后运行。为 `$seal`、`$sealedZip` 指定该次旧版本归档回执与对应 ZIP，从放行记录取得 `$sealSha`。将 `$journal` 和 `$installReceipt` 指向工程外的本次升级归档。安装命令核对封存包哈希和终态，锁住两个登记队列并检查其中所有请求已结束。轮换对象是经过 PID、创建时间、项目、命令行及直属子进程核查的默认宿主。历史专用队列与任务记录保留。

```powershell
& $python -B install.py install --target $project --release-sha256 $releaseSha --seal $seal --seal-sha256 $sealSha --archive $sealedZip --journal $journal --receipt $installReceipt
```

遇到中断时，先核对 `$journal` 的 release 与工程路径，再以相同日志文件和新回执名称重试。安装器只接受本次发行版规定的原文件或已安装文件。中间混合状态必须有对应日志；发生其他文件变更会停止安装。

## 验收和复现

输出目录须位于工程外且尚不存在。真实 PowerShell 入口应拒绝 candidate 登记并允许 100 个作业的 dry-run 预览。真实 stdio MCP 连接测试使用新的私有队列和合成数据。回归包括软检查、同一 OS 进程原地延时、硬上限、归属核验、P3 和 P4 门槛。

```powershell
& $python -B verify.py --target $project --output $verificationDirectory
```

新版会改变未来批次的运行器源码指纹。旧 E0 实验的复现使用本轮封存的原始运行器与原二进制，旧结果保留其原科学身份。安装器内保存的 `original-files.zip` 仅包含本次实际替换的四个原文件。完整历史复现所需的模拟器、原始输入和日志由相应的研究归档提供。
