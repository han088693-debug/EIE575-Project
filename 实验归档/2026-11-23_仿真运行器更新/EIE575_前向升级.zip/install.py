"""Install one version of the EIE575 runtime only after the two prior E0 requests are closed and archived."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import uuid
from zipfile import ZipFile

import psutil

PACKAGE = Path(__file__).resolve().parent
LIVE = Path(r"E:\Temp\eie575_tabr")
REQUESTS = {"e3e46441f32b6caa03", "e5e0f603c259082a01"}
ENDED = {"completed", "failed", "cancelled", "interrupted"}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda: f.read(2**20), b""):
            h.update(part)
    return h.hexdigest()


def atomic(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with tmp.open("xb") as f:
            f.write(raw)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def save(path, obj):
    atomic(path, (json.dumps(obj, indent=2, ensure_ascii=False) + "\n").encode())


def file_states(target, release):
    states = {}
    for name, terms in release["files"].items():
        path = (target / name).resolve()
        need(path.is_relative_to(target), "Unexpected release member")
        digest = sha(path) if path.is_file() else None
        need(digest in terms.values(), f"Source differs from both signed versions: {name}")
        states[name] = "after" if digest == terms["after"] else "before"
    return states


def require_recoverable(target, states, journal, pin):
    if len(set(states.values())) > 1:
        need(journal.is_file() and read(journal) == {"release": pin, "project": str(target)},
             "Mixed files without this installer's recovery journal")


def update_files(target, release, states, journal, pin):
    require_recoverable(target, states, journal, pin)
    if set(states.values()) == {"after"}:
        return []
    save(journal, {"release": pin, "project": str(target)})
    installed = []
    with ZipFile(PACKAGE / "files.zip") as z:
        need(set(z.namelist()) == set(states), "Payload membership mismatch")
        for name, state in states.items():
            if state == "after":
                continue
            raw = z.read(name)
            need(hashlib.sha256(raw).hexdigest() == release["files"][name]["after"], "Corrupt payload " + name)
            atomic(target / name, raw)
            installed.append(name)
    need(set(file_states(target, release).values()) == {"after"}, "Post-install digest check failed")
    return installed


def closure(target):
    index_path = target / "results/calibration/core_v1_budget2/index.json"
    index = read(index_path)
    selected = {r["request_id"]: r for r in index["requests"] if r["request_id"] in REQUESTS}
    need(set(selected) == REQUESTS and index["status"] not in {"submitting", "submitted", "running"},
         "Prior E0 index has not reached its recorded terminal state")
    status = {}
    queues = []
    for key, row in selected.items():
        need(row["state"] in {"accepted", "engineering_failed", "invalid_measurement"}, "Open prior request " + key)
        q = Path(row["queue"]).resolve()
        task = q / "requests" / key / "state.json"
        state = read(task)
        need(state["request_id"] == key and state["state"] in ENDED, "MCP task is not terminal " + key)
        queues.append(q)
        status[key] = {"index_state": row["state"], "mcp_state": state["state"], "mcp_sha256": sha(task)}
    return {"index_sha256": sha(index_path), "index_state": index["status"], "requests": status}, queues


def idle(queue):
    for path in (queue / "requests").glob("*/state.json"):
        need(read(path)["state"] in ENDED, "Queue contains unfinished work: " + str(path))


def checked_host(queue, target):
    receipt = read(queue / "host.json")
    need(Path(receipt["project"]).resolve() == target and
         Path(receipt["batch_root"]).resolve() == target / "results/batches", "Foreign host registration")
    identity = receipt["identity"]
    if not psutil.pid_exists(identity["pid"]):
        return None
    proc = psutil.Process(identity["pid"])
    need(abs(proc.create_time() - identity["create_time"]) < 0.001, "Host PID reused")
    argv = proc.cmdline()
    need(len(argv) >= 3 and argv[-1] == "--serve" and Path(argv[-2]).resolve() == target / "tools/formal_mcp.py",
         "Unexpected command for registered host")
    need(not proc.children(recursive=True), "Default host still owns a child")
    return proc


def approved_seal(args):
    need(args.seal and args.seal_sha256 and args.archive, "Sealed archive, receipt and approved receipt SHA required")
    need(sha(args.seal) == args.seal_sha256, "Archive receipt SHA mismatch")
    archive_sha = sha(args.archive)
    need(archive_sha.lower() in json.dumps(read(args.seal)).lower(), "Receipt does not bind the sealed archive")
    return {"receipt": str(args.seal.resolve()), "receipt_sha256": args.seal_sha256,
            "archive": str(args.archive.resolve()), "archive_sha256": archive_sha}


def install_live(args, target, release, result):
    closed, queues = closure(target)
    result.update(closure=closed, old_source_archive=approved_seal(args))
    settings = read(target / "configs/core.json")["tools"]
    sys.path.insert(0, settings["mcp_dir"])
    from controller import start_lock
    queue = Path(tempfile.gettempdir()) / ("tabr_formal_" + hashlib.sha256(str(target).casefold().encode()).hexdigest()[:12])
    need(queue in queues, "Unrecognized default queue")
    for q in queues:
        idle(q)
    # Prevent new submissions on the relevant queues during code replacement.
    with ExitStack() as locked:
        for q in sorted(set(queues)):
            locked.enter_context(start_lock(q))
            idle(q)
        before = file_states(target, release)
        require_recoverable(target, before, args.journal, args.release_sha256)
        proc = checked_host(queue, target)
        if proc is not None:
            result["prior_host"] = {"pid": proc.pid, "created": proc.create_time()}
            proc.terminate()
            proc.wait(10)
        result["installed"] = update_files(target, release, before, args.journal, args.release_sha256)
    env = dict(os.environ, EIE575_FORMAL_QUEUE=str(queue), EIE575_FORMAL_BATCH_ROOT=str(target / "results/batches"))
    cmd = [settings["mcp_python"], "-B", str(target / "tools/formal_mcp.py"), "--start-host"]
    started = subprocess.run(cmd, cwd=target, env=env, capture_output=True, text=True, timeout=35, check=True)
    host = json.loads(started.stdout)
    need(host["ready"] and checked_host(queue, target) is not None, "New default host unavailable")
    result["current_host"] = host


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=["check", "check-closure", "rehearse", "install"])
    p.add_argument("--target", type=Path, required=True)
    p.add_argument("--release-sha256", required=True)
    p.add_argument("--receipt", type=Path, required=True)
    p.add_argument("--journal", type=Path)
    p.add_argument("--seal", type=Path)
    p.add_argument("--seal-sha256")
    p.add_argument("--archive", type=Path)
    args = p.parse_args()
    target = args.target.resolve()
    require_live = args.mode == "install"
    try:
        need(sha(PACKAGE / "release.json") == args.release_sha256, "Release SHA mismatch")
        release = read(PACKAGE / "release.json")
        need(sha(PACKAGE / "files.zip") == release["payload_zip_sha256"] and
             sha(PACKAGE / "original-files.zip") == release["original_zip_sha256"], "Release payload SHA mismatch")
        need(not args.receipt.resolve().is_relative_to(target), "Install receipts must sit outside the project")
        need(not args.receipt.exists(), "Use a fresh install receipt path")
        previous = file_states(target, release)
        report = {"mode": args.mode, "target": str(target), "release_sha256": args.release_sha256, "before": previous}
        if args.mode == "check-closure":
            report["closure"], _ = closure(target)
        if args.mode in ("install", "rehearse"):
            need(args.journal and not args.journal.resolve().is_relative_to(target), "An external journal is required")
            if require_live:
                need(target == LIVE, "Production install restricted to its registered project")
                install_live(args, target, release, report)
            else:
                need(target != LIVE and (target / "FORWARD_REHEARSAL_ONLY").is_file(), "Rehearsal target is not marked")
                report["installed"] = update_files(target, release, previous, args.journal, args.release_sha256)
        report["result"] = "passed"
        report["after"] = file_states(target, release)
        save(args.receipt, report)
        print(json.dumps({"result": "passed", "receipt": str(args.receipt), "installed": report.get("installed", [])}))
        return 0
    except (ValueError, OSError, KeyError, RuntimeError, subprocess.SubprocessError, psutil.Error) as exc:
        print(json.dumps({"result": "blocked", "error": str(exc)}, ensure_ascii=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
