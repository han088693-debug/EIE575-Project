"""Check the deployed entry points with synthetic inputs and an isolated queue; never submit an E0 or formal job."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--target", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    opt = p.parse_args()
    target, out = opt.target.resolve(), opt.output.resolve()
    if out.is_relative_to(target):
        raise ValueError("Use an evidence folder outside the project")
    out.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(target / "tools"))
    import experiment as ex
    cfg = ex.json_read(target / "configs/core.json")
    tools = cfg["tools"]
    release = ex.json_read(Path(__file__).with_name("release.json"))
    assert all(ex.file_hash(target / k) == r["after"] for k, r in release["files"].items())
    assert ex.simulation_sources(target) == release["source_fingerprint_after"]
    env = dict(os.environ, PYTHONPATH=os.pathsep.join(str(target / f) for f in ("tests","tools")),
               PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1")

    def run(name, cmd, expected=0):
        success = subprocess.run(cmd, cwd=target, env=env, capture_output=True, timeout=150)
        (out / (name+".log")).write_bytes(success.stdout+success.stderr)
        if success.returncode != expected:
            raise RuntimeError(f"{name} exited {success.returncode}, expected {expected}")
        return success.stdout or success.stderr

    def wrappers():
        common = ["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File",str(target/"experiment.ps1"),
                  "-Action","plan","-Config",str(target/"configs/core.json"),"-Python",tools["analysis_python"]]
        candidate, preview = out/"rejected",out/"preview"
        deny = json.loads(run("candidate-gate",common+["-Output",str(candidate)],2))
        dry = json.loads(run("candidate-preview",common+["-Output",str(preview),"-DryRun"]))
        assert "frozen" in deny["error"] and dry["dry_run"] and dry["formal_jobs"]==100
        assert not candidate.exists() and not preview.exists()
        return {"candidate_exit":2,"actual_registration":False,"dry_run_formal_jobs":dry["formal_jobs"],
                "dry_run_pairs":dry["paired_blocks"]}

    def unit():
        suites = ["test_wall_budget","test_initial_wall_budget","test_formal_engine","test_experiment",
                  "test_p3_readiness","test_p4_blocks","test_timeout_retry","test_timeout_recovery"]
        run("regression",[tools["analysis_python"],"-B","-m","unittest","-v",*suites])

    def protocol():
        run("mcp",[tools["mcp_python"],"-B",str(target/"tests/test_formal_mcp.py"),
                   "--evidence",str(out/"mcp-synthetic")])
        r=ex.json_read(out/"mcp-synthetic/report.json")
        assert r["passed"] and r["scope"]=="synthetic" and r["repeat_request_deduplicated"] and not r["owned_process_alive"]
        return r

    with ThreadPoolExecutor(max_workers=3) as pool:
        w, u, s = pool.submit(wrappers),pool.submit(unit),pool.submit(protocol)
        wrapper = w.result()
        u.result()
        mcp = s.result()
    logs=sorted(out.glob("*.log"))
    result=dict(passed=True,target=str(target),wrapper=wrapper,mcp=mcp,
                simulated_science_jobs_started=0,sources_verified=release["source_fingerprint_after"],
                checked_files={k:ex.file_hash(target/k) for k in release["files"]},
                logs={f.name:ex.file_hash(f) for f in logs})
    ex.save(out/"verification.json",result)
    print(json.dumps(dict(passed=True,target=str(target),report=str(out/"verification.json"))))


if __name__=="__main__":
    main()
