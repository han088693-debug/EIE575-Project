"""Read a frozen E0 index and independently recompute exposure, gates and spatial/traffic checks."""
import argparse
from bisect import bisect_right
from collections import defaultdict
import csv
import hashlib
import json
import math
import os
from pathlib import Path
from statistics import fmean

TARGETS=("lead","follow")
PS=10**12
Q=PS//10
GROUPS=("target","registered_background_receivers","background_at_road_edges","all_vehicles")


def load(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):
    with p.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
def check(cond,message):
    if not cond: raise ValueError(message)
def close(a,b,tol=2e-10):
    check(math.isclose(a,b,rel_tol=1e-10,abs_tol=tol),f"Independent value differs: {a} vs {b}")
def cols(p):
    with p.open(encoding="utf-8-sig",newline="") as f: yield from csv.DictReader(f)
def compact(p,fields):
    with p.open(encoding="utf-8-sig",newline="") as f:
        reader=csv.reader(f);header=next(reader); ix=[header.index(k) for k in fields.split()]
        for row in reader: yield [row[i] for i in ix]
def ps(x): return round(float(x)*PS)
def quantile(v,p):
    x=sorted(v); k=(len(x)-1)*p;i=int(k);return x[i]+(k-i)*(x[math.ceil(k)]-x[i])
def put(path,values):
    tmp=path.with_name(path.name+".tmp")
    tmp.write_text(json.dumps(values,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    os.replace(tmp,path)
def dump_csv(p,values):
    with p.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=list(values[0]));w.writeheader();w.writerows(values)


def busy_boundaries(path,life):
    """Evaluate the cumulative integral of the binary MAC busy timeline on grid boundaries."""
    by={v:([],[],[]) for v in TARGETS}
    for v,t,s in compact(path,"vehicle_id transition_time busy_state"):
        if v not in by: continue
        times,levels,areas=by[v]; t=ps(t);s=int(s)
        check(s in (0,1) and (not times or t>=times[-1]),"Invalid busy transition")
        if not times: check(t==life[v][0] and s==0,"Missing initial idle state")
        areas.append(areas[-1]+levels[-1]*(t-times[-1]) if times else 0)
        times.append(t);levels.append(s)
    output={}
    for v,(ts,ss,aa) in by.items():
        def integral(t):
            i=bisect_right(ts,t)-1;return aa[i]+ss[i]*(t-ts[i])
        beg,end=life[v];output[v]={t:(integral(t+Q)-integral(t))/PS for t in range(beg,end,Q)}
    return output


def analyze(row,root,project):
    report=load(root/row["report"])
    probe=(project/"results/probes"/row["probe"]/row["request_id"]).resolve()
    check(probe.is_relative_to(project.resolve()),"Probe path escaped selected project")
    found=list(probe.rglob(row["attempt_id"]))
    check(len(found)==1 and found[0].is_dir(),"Cannot locate registered attempt under selected project")
    run=found[0]
    manifest=load(run/"run_manifest.json")
    check(sha(root/row["report"])==row["report_sha256"] and sha(run/"run_manifest.json")==row["manifest_sha256"],"Index hashes differ")
    check(manifest["data_origin"]=="simulation" and manifest["status"]=="completed" and manifest["data_valid"] is True
          and manifest["attempt_id"]==row["attempt_id"] and manifest["simulation_job_key"]==row["simulation_job_key"],"Wrong run identity")
    keys=dict(density=int(report["density"]),warmup_s=report["warmup_s"],seed=report["seed"])
    d,warm,seed=keys.values()
    check([d,warm,seed]==row["job"] and report["origin"]=="simulation","Wrong calibration job/origin")
    files=["config_snapshot.json","inputs/pairs.csv","inputs/vehicles.csv","inputs/scenario.json",
           "logs/sumo_diagnostics.json","logs/engine_status.json","logs/lifecycle.csv","logs/control_log.csv","logs/busy_audit.csv",
           "logs/local_supply.csv","logs/tx_log.csv"]
    diag=load(run/"logs/sumo_diagnostics.json")
    rawsummary=diag["raw_evidence_paths"]["summary.xml"].replace("\\","/")
    files.append(rawsummary)
    hashes={n:sha(run/n) for n in files}
    check(all(h==manifest["files"][n] for n,h in hashes.items()),"Raw source checksum failure")
    engine=load(run/"logs/engine_status.json")
    check(engine["engine_complete"] is True and engine["return_code"]==0 and engine["status"]=="completed","Incomplete simulator execution")
    cfg=load(run/"config_snapshot.json"); cal=cfg["calibration"]; geo=load(run/"inputs/scenario.json")
    check((cfg["scenario"],cfg["scheme"],cfg["density_per_lane_km"],cfg["seed"])==("E0","G0",d,seed)
          and geo["valid"] and geo["distribution"]=="uniform_full_road","Unexpected traffic setup")
    cars=list(cols(run/"inputs/vehicles.csv"));life_rows=list(cols(run/"logs/lifecycle.csv"))
    carset={r["vehicle_id"] for r in cars}; active={r["vehicle_id"] for r in life_rows}
    check(len(cars)==len(carset)==len(life_rows) and active==carset,"Traffic roster and actual lifetime IDs differ")
    life={r["vehicle_id"]:(ps(r["enter_s"]),ps(r["exit_s"])) for r in life_rows if r["vehicle_id"] in TARGETS}
    busy=busy_boundaries(run/"logs/busy_audit.csv",life)
    registered={r["receiver_id"] for r in cols(run/"inputs/pairs.csv") if r["role"]=="background"}
    check(len(registered)==10 and registered.isdisjoint(TARGETS),"Wrong 10 background receiver roster")
    bounds=[int(PS*x) for x in (warm-10,warm-5,warm,warm+30,warm+60,warm+90)]
    groups={g:[defaultdict(lambda:[0.,0]) for _ in range(5)] for g in GROUPS}
    intervals={v:{} for v in TARGETS};err={v:0. for v in TARGETS}
    road=cfg["geometry"]["length_m"]; edge=cfg["geometry"].get("edge_distance_m",1000)
    for v,a,b,t,c,s,r,busy_s,x in compact(run/"logs/control_log.csv","vehicle_id window_start window_end tick_time C Cbar r busy_duration_s lane_position_m"):
        a,b=ps(a),ps(b);c=float(c)
        if v in intervals:
            check(ps(t)==b and b==a+Q and a not in intervals[v] and a in busy[v],"Invalid target CBR grid")
            busy_s=float(busy_s);er=abs(busy[v][a]-busy_s);err[v]=max(err[v],er)
            close(c,busy_s*10,1e-8);check(er<=1e-8,"Independent busy integral failed")
            intervals[v][a]=(c,float(s),float(r))
        i=bisect_right(bounds,a)-1
        if not 0<=i<5: continue
        check(b<=bounds[i+1] and b>a,"Partial or unaligned spatial window")
        x=float(x);who=["all_vehicles"]
        if v in TARGETS: who+=["target"]
        else:
            if v in registered: who+=["registered_background_receivers"]
            if min(x,road-x)<=edge: who+=["background_at_road_edges"]
        for group in who:
            acc=groups[group][i][v];acc[0]+=c*(b-a)/PS;acc[1]+=b-a
    local={v:{} for v in TARGETS}; submitted={v:[] for v in TARGETS}
    for v,t,n in compact(run/"logs/local_supply.csv","vehicle_id t background_count"):
        if v in local:
            t=ps(t);check(t not in local[v],"Duplicate supply tick");local[v][t]=int(n)
    for v,t in compact(run/"logs/tx_log.csv","sender_id t_submit"):
        if v in submitted: submitted[v].append(ps(t))
    windows=[];spatial=[];qualified={};failures={}
    for v in TARGETS:
        check(len(intervals[v])==len(busy[v]),"Incomplete all-window target control coverage")
        refs=report["targets"][v]
        close(err[v],refs["max_busy_error_s"],1e-10)
        pre=fmean(local[v][t] for t in range(bounds[0],bounds[2],Q))
        vehicle=[]
        for i,(a,b) in enumerate(zip(bounds,bounds[1:])):
            g=range(a,b,Q);c,sm,r=zip(*(intervals[v][t] for t in g))
            raw=fmean(c); span=quantile(sm,.9)-quantile(sm,.1); supply=fmean(local[v][t] for t in g)
            frac=sum(1+1e-6<rate<=9.5 for rate in r)/len(r);sat=sum(rate>=10-1e-9 for rate in r)/len(r)
            ref=refs["windows"][i]
            for num,k in ((raw,"raw_cbr_mean"),(span,"smoothed_p90_minus_p10"),(supply,"local_count_mean")):close(num,ref[k])
            tx_count=sum(a<=t<b for t in submitted[v])
            vehicle.append(dict(**keys,vehicle=v,window=i+1,start_s=a//PS,end_s=b//PS,raw_cbr=raw,
                                smoothed_p90_minus_p10=span,smoothed_cbr_min=min(sm),smoothed_cbr_max=max(sm),local_count_mean=supply,
                                local_count_vs_prewindow=(supply/pre-1),feedback_fraction=frac,cap_10hz_fraction=sat,
                                feedback_s=frac*(b-a)/PS,cap_10hz_s=sat*(b-a)/PS,
                                target_rate_hz=fmean(r),actual_submits=tx_count,actual_submits_hz=tx_count*PS/(b-a),
                                max_busy_error_s_all_windows=err[v]))
        ok=True
        for j,r in enumerate(vehicle):
            delta=r["raw_cbr"]-vehicle[1]["raw_cbr"];r["cbr_minus_last_prewindow"]=delta
            ok&= abs(delta)<= (cal["max_prewindow_drift"] if j<2 else cal["max_longwindow_drift"])+1e-12
            ok&=r["smoothed_p90_minus_p10"]<=cal["max_smoothed_span"]+1e-12
            if j>=2: ok&=abs(r["local_count_vs_prewindow"])<=cal["max_supply_drift"]+1e-12
        f=fmean(r["feedback_fraction"] for r in vehicle[2:]);close(f,refs["feedback_exposure_fraction"])
        low=all(r["raw_cbr"]<=cal["low_max"]+1e-12 for r in vehicle)
        high=all(cal["high_min"]-1e-12<=r["raw_cbr"]<=cal["high_max"]+1e-12 for r in vehicle)
        qualified[v]=(ok,ok and low,ok and high and f+1e-12>=cal["feedback_exposure_min"])
        failures[v]=dict(feedback_fraction_post=f,raw_cbr_windows_below_high=sum(r["raw_cbr"]<cal["high_min"]-1e-12 for r in vehicle),
                         raw_cbr_windows_above_high=sum(r["raw_cbr"]>cal["high_max"]+1e-12 for r in vehicle))
        windows.extend(vehicle)
    flags=[all(qualified[v][i] for v in TARGETS) for i in range(3)]
    check(flags==[report[k] for k in ("stable","low","high")],"Eligible flags differ")
    for group,accs in groups.items():
        for i,acc in enumerate(accs):
            total=sum(v[1] for v in acc.values())/PS;equal=fmean(v[0]*PS/v[1] for v in acc.values())
            weighted=sum(v[0] for v in acc.values())/total
            ref=report["spatial_cbr"]["populations"][group][i]
            check(len(acc)==ref["exposed_vehicles"],"Spatial roster mismatch")
            close(total,ref["observed_vehicle_seconds"],1e-7);close(equal,ref["vehicle_equal_mean_cbr"]);close(weighted,ref["exposure_weighted_mean_cbr"])
            spatial.append(dict(**keys,window=i+1,start_s=bounds[i]//PS,end_s=bounds[i+1]//PS,population=group,
                                exposed_vehicles=len(acc),vehicle_seconds=total,vehicle_equal_mean_cbr=equal,exposure_weighted_cbr=weighted))
    import xml.etree.ElementTree as ET
    latest=ET.parse(run/rawsummary).getroot().findall("step")[-1].attrib
    n=len(cars)
    check(int(latest["inserted"])==diag["actual_entries"]==diag["expected_entries"]==n and int(latest["running"])+int(latest["arrived"])==n
          and all(diag[k]==0 for k in ("insertion_failures","unexplained_teleports","unexplained_removals")),"Incomplete traffic")
    background=[r for r in cars if r["role"]=="background"]
    n0=sum(r["prefill"]=="1" for r in background);check(n0==geo["background_prefill_n"] and n0==d*32,"Wrong uniform prefill")
    return dict(key=keys,windows=windows,spatial=spatial,flags=flags,failures=failures,
                traffic=dict(**keys,prefill_background=n0,subsequent_background=len(background)-n0,spacing_m=geo["uniform_spacing_m"],
                             expected=n,actual=int(latest["inserted"]),arrived=int(latest["arrived"]),running_at_end=int(latest["running"]),
                             sumo_teleports=int(latest["teleports"]),unexplained_removals=diag["unexplained_removals"],
                             insertion_failures=diag["insertion_failures"],unexplained_teleports=diag["unexplained_teleports"],
                             engine_seconds=engine["wall_seconds"],attempt_seconds=manifest["wall_seconds"],
                             peak_process_tree_private_bytes=engine["peak_private_bytes"],output_bytes=manifest.get("output_bytes")),
                attempt_id=row["attempt_id"],request_id=row["request_id"],report_sha256=row["report_sha256"],
                manifest_sha256=row["manifest_sha256"],raw_sha256=hashes,design_sha256=report["design_sha256"])


def geometry(project,decision):
    result=[]
    for item in decision["geometry_exclusions"]:
        d=int(item["density_per_lane_km"])
        check({s["seed"] for s in item["reports"]}=={100,101},"Missing geometry seed")
        for s in item["reports"]:
            seed=s["seed"]
            path=project/f"verification/p2/sumo/geometry_exclusion_d{d}_seed{seed}/inputs/scenario.json"
            r=load(path); filters=r["filtering"]; g=r["config_geometry"]
            check(sha(path)==s["report_sha256"] and r==s["report"] and r["valid"] is False and
                  r["simulation_started"] is False and r["seed"]==seed and r["density_per_km_lane"]==d and
                  g["length_m"]==8000 and g["background_lanes"]==4 and g["pair_max_distance_m"]==250 and
                  r["uniform_spacing_m"]>250 and r["eligible_background_pairs"]==0 and r["required_background_pairs"]==10 and
                  r["complete_adjacent_pairs_scanned"]==filters["excluded_distance"]+filters["excluded_outside_window"]
                  and filters["disjoint_counts"] is True,"Failed sparse geometric exclusion review")
            result.append(dict(density=d,seed=seed,roster_sha256=s["report_sha256"],spacing_m=r["uniform_spacing_m"],
                               complete_adjacent_pairs_scanned=r["complete_adjacent_pairs_scanned"],
                               excluded_distance=filters["excluded_distance"],excluded_outside_window=filters["excluded_outside_window"]))
    return result


def joined(reports,decision,geometric):
    decisions=[]
    for d in (1,2,5,10,15,20,25,30):
        relevant=[r for r in reports if r["key"]["density"]==d]
        warms=sorted({r["key"]["warmup_s"] for r in relevant}) or [None]
        for w in warms:
            group=[r for r in relevant if r["key"]["warmup_s"]==w]
            flags={r["key"]["seed"]:r["flags"] for r in group}
            geo=any(r["density"]==d for r in geometric)
            check(not (geo and group),"Geometric exception cannot count a radio run")
            wins=[m for r in group for m in r["windows"]]
            post=[m for m in wins if m["window"]>=3]
            spatial=[m for r in group for m in r["spatial"] if m["population"]=="target"]
            fb=[v["feedback_fraction_post"] for r in group for v in r["failures"].values()]
            cap=[fmean(m["cap_10hz_fraction"] for m in r["windows"] if m["vehicle"]==v and m["window"]>=3) for r in group for v in TARGETS]
            st=all(f[0] for f in flags.values()) if len(group)==2 else None
            low=all(f[1] for f in flags.values()) if len(group)==2 else None
            high=all(f[2] for f in flags.values()) if len(group)==2 else None
            state=("几何排除" if geo else "待测" if not group else "待补第二种子" if len(group)<2 else
                   "需复核稳定性" if not st else "低档合格" if low else "高档合格" if high else "两个负载档均不合格")
            lower=lambda g,k:min((x[k] for x in g),default=None)
            upper=lambda g,k:max((x[k] for x in g),default=None)
            miss_low=sum(m["raw_cbr"]>.30+1e-12 for m in wins)
            miss_high=sum(not .50-1e-12<=m["raw_cbr"]<=.65+1e-12 for m in wins)
            cause=("同道节距超过250 m；无10个预登记车对，无无线CBR" if geo else "尚无已验收无线运行" if not group else
                   f"{miss_low}/{len(wins)}个目标单车窗口不满足低档CBR；{miss_high}/{len(wins)}不满足高档CBR；"
                   f"{sum(v<.25-1e-12 for v in fb)}/{len(fb)}个目标车×种子的90秒调率占比低于25%")
            decisions.append(dict(density=d,warmup_s=w,radio_runs=len(group),status=state,stable=st,low=low,high=high,
                                  seed100_flags=flags.get(100),seed101_flags=flags.get(101),
                                  target_single_min_cbr=lower(wins,"raw_cbr"),target_single_max_cbr=upper(wins,"raw_cbr"),
                                  target_equal_min_cbr=lower(spatial,"vehicle_equal_mean_cbr"),target_equal_max_cbr=upper(spatial,"vehicle_equal_mean_cbr"),
                                  min_feedback_fraction=min(fb,default=None),max_feedback_fraction=max(fb,default=None),
                                  min_cap_10hz_fraction=min(cap,default=None),max_cap_10hz_fraction=max(cap,default=None),
                                  local_min_mean=lower(post,"local_count_mean"),local_max_mean=upper(post,"local_count_mean"),
                                  reason=cause))
    return decisions


def note(out,decisions,reports,decision,index,terminal):
    state=decision["status"];chosen=decision.get("selected",{})
    rows=[r for r in decisions if r["radio_runs"]]
    candidates=lambda k: [r["density"] for r in rows if r[k]]
    highest=max(rows,key=lambda r:r["target_equal_max_cbr"])
    lowest=min(rows,key=lambda r:r["target_equal_min_cbr"])
    fmt=lambda x,precision=2: f"{100*x:.{precision}f}%"
    def rng(a,b,digits=2):
        if a is None:return "—"
        return fmt(a,digits) if abs(a-b)<1e-12 else fmt(a,digits)+"–"+fmt(b,digits)
    windows=[m for r in reports for m in r["windows"]]; post=[m for m in windows if m["window"]>=3]
    total_runs=len(reports); retries=sum(j["state"]=="engineering_failed" for j in index["requests"])
    lines=["# E0 背景负载校准判定",""]
    if state=="grid_exhausted":
        lines+=[f"**当前设计可达到低档，固定网格内没有高档。** 两个种子都通过低档的密度为 {', '.join(map(str,candidates('low')))} 辆/km/车道，最低合格密度为 {chosen['low']}。P3 仍缺同时合格的低、高负载，P4 正式矩阵继续暂停。"]
    elif state=="selected":
        lines+=[f"**两档均通过，低档为 {chosen['low']}、高档为 {chosen['high']} 辆/km/车道。** 后续仍须完成其余 P3 放行要求。"]
    else:lines+=[f"**阶段快照，尚未结束校准。** 当前决策为 `{state}`，下一组任务以主线 decision.json 为准。"]
    lines+=["",f"本表独立复算 {total_runs} 个已接受的 E0/G0 无急刹运行。每密度分开核对种子 100、101，各验收运行的目标单车判定、实际 MAC 忙时复算和空间统计均与已登记测量一致。当前工程失败记录 {retries} 次，其日志保留且不计有效校准运行。低、高档规则均作用于每辆目标车的每个窗口。两车等权汇总仅用于描述。","",
            "| 背景密度（辆/km/车道）| 验收运行 | 两目标等权 CBR 范围 | 目标单车窗口 CBR 范围 | 90 s 调率时长占比范围 | 90 s 达 10 Hz 占比范围 | 结论 |",
            "|---:|---:|---:|---:|---:|---:|---|"]
    for r in decisions:
        lines+=[f"| {r['density']} | {r['radio_runs']} | {rng(r['target_equal_min_cbr'],r['target_equal_max_cbr'])} | {rng(r['target_single_min_cbr'],r['target_single_max_cbr'])} | {rng(r['min_feedback_fraction'],r['max_feedback_fraction'])} | {rng(r['min_cap_10hz_fraction'],r['max_cap_10hz_fraction'])} | {r['status']} |"]
    lines+=["","## 负载与诊断","",
            f"在实际测过的密度与两个种子内，目标两车等权窗口 CBR 的最低与最高观测值为 {fmt(lowest['target_equal_min_cbr'])}、{fmt(highest['target_equal_max_cbr'])}。低档要求每个目标车每窗 ≤30%。高档要求每窗为 50%–65%，且长窗内每辆目标车至少 25% 的时间满足 1.000001 < r ≤ 9.5 Hz。",
            "",f"空间统计先按单车在该区域的实际暴露时长计算 CBR，再对车辆等权。边缘指背景车处在道路纵向两端各 1 km 的时段。以观测最高的密度 {highest['density']} 为例，五窗及各已接受种子的范围为"]
    at_high=[m for r in reports if r["key"]["density"]==highest["density"] for m in r["spatial"]]
    for k,label in zip(GROUPS,("目标两车","十个已登记背景接收车","背景边缘车辆","全网车辆")):
        vals=[v["vehicle_equal_mean_cbr"] for v in at_high if v["population"]==k]
        lines.append(f"- {label}：{rng(min(vals),max(vals))}。")
    lines+=["",f"两个 5 s 暖机窗接三个 30 s 长窗。逐车平滑 CBR 的 p90−p10 最大为 {max(x['smoothed_p90_minus_p10'] for x in windows):.4f}（门槛 0.10），后段单窗相对最后暖机窗原始 CBR 最大绝对差为 {max(abs(x['cbr_minus_last_prewindow']) for x in post):.4f}（门槛 0.05）。局部供给为观察者前后各 1 km 内四条背景车道车辆总数，长段相对前 10 s 的最大变化为 {fmt(max(abs(x['local_count_vs_prewindow']) for x in post))}（门槛 15%）。",
            "",f"全部目标控制窗从 MAC busy 状态变更重新积分，和引擎记录相差最多 {max(x['max_busy_error_s_all_windows'] for x in windows):.3g} s（门槛 1e-8 s）。SUMO 注册车辆、实际生命周期 ID 逐一对齐，各运行的已到达车辆数加结束时运行数与插入数相等；无漏插和未解释的移除或瞬移。"]
    if state=="grid_exhausted":
        d=highest["density"]; rr=[r for r in reports if r["key"]["density"]==d]
        pre=rr[0]["traffic"];gap=.50-highest["target_single_max_cbr"]
        lines+=["",f"最高实测档 {d} 的单车五窗最高 CBR 为 {fmt(highest['target_single_max_cbr'])}，"
                +(f"仍比高档最低值低 {gap*100:.2f} 个百分点。" if gap>0 else "个别窗口达标仍须核对其余窗口。")+
                f"此档预填 {pre['prefill_background']} 辆背景车，目标局部供给均值 {highest['local_min_mean']:.1f}–{highest['local_max_mean']:.1f} 辆，90 s 调率占比 {rng(highest['min_feedback_fraction'],highest['max_feedback_fraction'])}。"
                "高档有独立的占用与调率两道门槛。目标与背景中心位置的实测结果、稳定暴露和车流对账均不支持将缺口归因于漏插、观察者附近车流消失或道路边缘均值稀释。"
                f"G0 的反馈目标为 0.60、死区为 ±0.03、增益为 0.5，r 上限为 10 Hz。该档长窗内两个目标的平滑 CBR 实测最大为 {fmt(max(m['smoothed_cbr_max'] for r in rr for m in r['windows'] if m['window']>=3))}。平滑占用低于 0.57 时控制器向上调基础率，达到上限后实际目标率保持 10 Hz。"
                "以上是当前消息、控制器、PHY/MAC、速度、四条车道和已测种子的可实现范围，不能据此外推其他无线设置的上限。",
                "","## 可讨论的第二版设计与预算（未执行）","",
                "一个单因素方案是保留四条背景车道、消息、速度、控制增益、门槛与两种子，只把候选密度向上扩至事前固定的 35、40 辆/km/车道。两档分别需要预填 1120、1280 辆，高于本版资源试跑最高的 960 辆。若在独立 SUMO 走查中不满足原路段、车对、间距或全窗供给，记录失败并停在该门槛；密度增加也不保证满足反馈调率条件。",
                "",f"可按 2 个新密度 × 2 种子安排 4 次 120 s E0 运行；另用新版登记对密度 5 复核 2 次，首轮最多 6 次。按事前的 20→40→60 s 稳定性规则，三档全部走完的上界为 18 次 E0，统一预热如有必要另计最多 4 次；独立 SUMO 和超出 960 辆的分级资源短测另列。作尺度参考，当前密度 {d} 的两个已接受运行各用 {min(r['traffic']['engine_seconds'] for r in rr)/60:.1f}–{max(r['traffic']['engine_seconds'] for r in rr)/60:.1f} 分钟，每次原始输出 {min(r['traffic']['output_bytes'] for r in rr)/1e6:.1f}–{max(r['traffic']['output_bytes'] for r in rr)/1e6:.1f} MB。新密度的工时、内存和磁盘须重新实测，不能按车数线性承诺。"]
    lines+=["","## 复核入口","","同目录含逐密度判定表 candidate_decisions.csv、逐车逐窗 target_windows.csv、四类空间汇总 spatial_windows.csv、进出场对账 traffic.csv，以及记录输入哈希、几何排除和终态的 verification.json。每个已接受运行的独立复算结果在 proofs/。建档时执行 `python -B review_e0.py --project <主线工程根> --out <新输出目录>`，无须启动仿真。"]
    (out/"E0_校准结论.md").write_text("\n".join(lines)+"\n",encoding="utf-8")


def figure(out,reports,geometric):
    from PIL import Image,ImageDraw,ImageFont
    image=Image.new("RGB",(1350,800),"white"); dr=ImageDraw.Draw(image)
    regular=Path(os.environ.get("WINDIR","C:/Windows"))/"Fonts/Deng.ttf"
    bold=regular.with_name("Dengb.ttf")
    def label(x,y,s,size=23,color="#243746",anchor="lm",strong=False):
        dr.text((x,y),s,font=ImageFont.truetype(str(bold if strong else regular),size),fill=color,anchor=anchor)
    x=lambda d:140+(d-1)*35
    y=lambda v:615-v*625
    teal,blue="#006E62","#345CAA"
    label(72,48,"背景密度与目标车辆的实测信道占用",35,strong=True)
    label(73,96,"E0 / G0 无急刹校准  ·  每个种子独立记录领车和跟车的五个窗口",23,"#4B6268")
    left,right=110,1205
    dr.rectangle((left,y(.65),right,y(.5)),fill="#E3F0E8")
    for val in (0,.1,.2,.3,.4,.5,.6,.65,.7):
        ypos=y(val); dr.line((left,ypos,right,ypos),fill="#C9D4D4" if val!=.30 else "#A28349",width=1 if val!=.30 else 3)
        label(94,ypos,f"{100*val:.0f}%",21,anchor="rm")
    label(1203,y(.575),"高档 CBR 区间 50%–65%  ",21,"#35624C","rm")
    label(1201,y(.3)-17,"低档上界 30%  ",19,"#81683D","rm")
    for density in (1,2,5,10,15,20,25,30):
        pos=x(density);dr.line((pos,y(0),pos,y(0)+6),fill="#35424A",width=2)
        label(pos,y(0)+27,str(density),19,anchor="mm")
    label(1210,y(0)+29,"密度",18,anchor="lm")
    for r in reports:
        k=r["key"]; c=teal if k["seed"]==100 else blue; dx=-7 if k["seed"]==100 else 7
        pos=x(k["density"])+dx; vals=[q["raw_cbr"] for q in r["windows"]]
        mid=fmean(q["raw_cbr"] for q in r["windows"] if q["window"]>=3)
        lo,hi=y(max(vals)),y(min(vals))
        dr.line((pos,lo,pos,hi),fill=c,width=3);dr.line((pos-5,lo,pos+5,lo),fill=c,width=2);dr.line((pos-5,hi,pos+5,hi),fill=c,width=2)
        if dx<0:dr.ellipse((pos-4,y(mid)-4,pos+4,y(mid)+4),fill=c)
        else:dr.rectangle((pos-3,y(mid)-3,pos+3,y(mid)+3),fill=c)
    for den in {g["density"] for g in geometric}:
        pos=x(den);dr.line((pos-4,667-4,pos+4,667+4),fill="#6F7779",width=2);dr.line((pos+4,667-4,pos-4,667+4),fill="#6F7779",width=2)
    label(205,667,"1、2：未满足车对几何要求，无无线仿真观测",19,"#526268")
    label(75,728,"● 种子 100",20,teal);label(231,728,"■ 种子 101",20,blue)
    label(390,728,"误差线为两车五个单车窗口均值的最小–最大值，标记为两车长窗等权平均。",20)
    label(75,765,"密度单位为辆/km/车道。横向位置轻微错开以区分种子；高档还要求两辆车各有至少 25% 的长窗时间处于调率区。",19,"#526268")
    image.save(out/"density_cbr.png")


def run(project,out,cache=None,index_root=None):
    project=Path(project).resolve(); out=Path(out).resolve();out.mkdir(exist_ok=True,parents=True)
    root=project/"results/calibration/core_v1"; state=index_root or root
    index=load(state/"index.json"); decision=load(state/"decision.json")
    accepted=[j for j in index["requests"] if j["state"]=="accepted"]
    if len(accepted)!=decision["completed_unique_runs"]: return False
    if cache is None:cache={}
    (out/"proofs").mkdir(exist_ok=True)
    proofs=[]
    for j in accepted:
        key=(j["request_id"],j["report_sha256"],j["manifest_sha256"])
        if key not in cache:
            cache[key]=analyze(j,root,project)
            put(out/"proofs"/(j["request_id"]+".json"),cache[key])
        proofs.append(cache[key])
    check(proofs and len({tuple(r["key"].values()) for r in proofs})==len(proofs),"Duplicate accepted scientific jobs")
    proofs.sort(key=lambda r: tuple(r["key"].values()))
    geo=geometry(project,decision); table=joined(proofs,decision,geo)
    terminal=decision["status"] in ("selected","grid_exhausted","common_warmup_failed")
    if terminal:
        for label in ("low","high"):
            expected=min((r["density"] for r in table if r[label]),default=None)
            check(decision["selected"][label]==expected if decision["status"]!="common_warmup_failed" else True,"Selection differs")
    dump_csv(out/"candidate_decisions.csv",table)
    for name,rows in (("target_windows",[m for r in proofs for m in r["windows"]]),
                      ("spatial_windows",[m for r in proofs for m in r["spatial"]]),("traffic",[r["traffic"] for r in proofs])):
        dump_csv(out/(name+".csv"),rows)
    note(out,table,proofs,decision,index,terminal);figure(out,proofs,geo)
    artifacts=("candidate_decisions.csv","target_windows.csv","spatial_windows.csv","traffic.csv","E0_校准结论.md","density_cbr.png")
    put(out/"verification.json",dict(complete=terminal,status=decision["status"],data_origin="simulation",source_index_sha256=sha(state/"index.json"),
        source_decision_sha256=sha(state/"decision.json"),accepted_unique_runs=len(proofs),source_design_sha256=decision["design_sha256"],
        selected=decision.get("selected"),next_runs=decision.get("next_runs"),geometry_exclusions=geo,
        target_windows=len(proofs)*10,spatial_windows=len(proofs)*20,verified_run_reports=[r["request_id"] for r in proofs],
        proof_sha256={r["request_id"]:sha(out/"proofs"/(r["request_id"]+".json")) for r in proofs},
        output_sha256={n:sha(out/n) for n in artifacts}))
    print(f"{len(proofs)} accepted; {decision['status']}; complete={terminal}",flush=True)
    return terminal


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project",type=Path,required=True);parser.add_argument("--out",type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument("--watch",action="store_true")
    args=parser.parse_args()
    import time
    cache={}; previous=None
    while True:
        root=args.project/"results/calibration/core_v1"
        anchor=(sha(root/"index.json"),sha(root/"decision.json"))
        if anchor!=previous:
            terminal=run(args.project,args.out,cache)
            if terminal or not args.watch:break
            previous=anchor
        time.sleep(15)
