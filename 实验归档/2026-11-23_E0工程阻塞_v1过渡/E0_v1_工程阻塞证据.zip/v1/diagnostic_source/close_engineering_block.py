"""Record a confirmed exhausted engineering retry without changing the E0 index or any run."""
import argparse
from statistics import fmean
from pathlib import Path
import review_e0 as ev


def close(project,out,request_id,index_root=None):
    project=project.resolve();out=out.resolve()
    root=index_root or project/"results/calibration/core_v1";i=ev.load(root/"index.json");d=ev.load(root/"decision.json")
    req=[r for r in i["requests"] if r["request_id"]==request_id]
    ev.check(len(req)==1 and req[0]["state"]=="engineering_failed" and req[0].get("timeout_extension"),
             "Need an actual failed registered extension request")
    failed=req[0];job=failed["job"]; ext=failed["timeout_extension"]
    earlier=[r for r in i["requests"] if r["job"]==job and r["request_id"]==ext["parent_request"]]
    ev.check(len(earlier)==1 and earlier[0]["state"]=="engineering_failed"
             and not any(r["job"]==job and r["state"]=="accepted" for r in i["requests"]),
             "No evidence of both failed attempts, or this scientific job already succeeded")
    ev.check(d["status"] not in ("grid_exhausted","selected","common_warmup_failed") and
             any([r["density_per_lane_km"],r["warmup_s"],r["seed"]]==job for r in d["next_runs"]),
             "Expected a pending scientific candidate, not a scientific terminal decision")
    ev.run(project,out,index_root=root)
    verification=ev.load(out/"verification.json")
    dens=job[0];missing=sorted({100,101}-{r["job"][2] for r in i["requests"] if r["job"][:2]==job[:2] and r["state"]=="accepted"})
    details=[]
    for r in (earlier[0],failed):
        probe=project/"results/probes"/r["probe"]/r["request_id"]
        paths=list(probe.rglob("run_manifest.json"))
        ev.check(len(paths)==1,"Failed run manifest missing or ambiguous")
        attempt=ev.load(paths[0])
        ev.check(attempt.get("data_valid") is not True and attempt["status"]!="completed" and r.get("mcp_state")=="failed","Failed attempt is marked valid")
        engine=paths[0].parent/"logs/engine_status.json"
        logs=engine.parent
        trace=logs/"resource_trace.csv"; final_sample=None
        for rec in ev.cols(trace): final_sample=rec
        meta=ev.load(engine)
        details.append(dict(request_id=r["request_id"],job=job,reason=r.get("reason"),
                            attempt_id=attempt["attempt_id"],run_status=attempt["status"],attempt_manifest_sha256=ev.sha(paths[0]),
                            engine_status_sha256=ev.sha(engine),resource_trace_sha256=ev.sha(trace),
                            max_wall_s=meta["wall_timeout_s"],last_wall_sample_s=float(final_sample["t_wall_s"]),
                            engine_complete=meta["engine_complete"]))
    failed_control=logs/"control_log.csv"; samples={v:{} for v in ev.TARGETS}
    for v,a,b,t,c,r in ev.compact(failed_control,"vehicle_id window_start window_end tick_time C r"):
        if v not in samples:continue
        left,right=ev.ps(a),ev.ps(b)
        ev.check(left not in samples[v] and right==left+ev.Q==ev.ps(t),"Invalid diagnostic target tick")
        samples[v][left]=(float(c),float(r))
    intervals=[(job[1]-10,job[1]-5),(job[1]-5,job[1]),(job[1],job[1]+30),(job[1]+30,job[1]+60),(job[1]+60,job[1]+90)]
    diagnostic=[]
    for v in ev.TARGETS:
        for a,b in intervals:
            times=range(a*ev.PS,b*ev.PS,ev.Q); selected=[samples[v][t] for t in times if t in samples[v]]
            diagnostic.append(dict(vehicle=v,start_s=a,end_s=b,expected=len(times),observed=len(selected),
                                   cbr=fmean(x[0] for x in selected) if len(selected)==len(times) else None,
                                   feedback_fraction=fmean(1+1e-6<x[1]<=9.5 for x in selected) if len(selected)==len(times) else None))
    diag=dict(control_sha256=ev.sha(failed_control),last_control_tick_s={v:(max(points)+ev.Q)/ev.PS for v,points in samples.items() if points},
              excluded_from_scientific_results=True,windows=diagnostic)
    label="engineering_blocked_retry_exhausted"
    note=out/"E0_校准结论.md";body=note.read_text(encoding="utf-8")
    replacement=(f"**工程阻塞：密度 {dens}、预热 {job[1]} s、seed {job[2]} 已用完该配置的预登记工程重试。** "
                 f"已接受 {verification['accepted_unique_runs']} 个真实科学运行。密度 {dens} 在该预热缺少已验收种子 {missing}。"
                 f"主线科学判定仍为 `{d['status']}`，网格未完成，不能从已有结果断言整个网格没有高档。P4 继续暂停。")
    lines=body.splitlines();ev.check(lines[2].startswith("**阶段快照"),"Unexpected intermediate report format");lines[2]=replacement
    lines+=["","## 失败回执与独立诊断（不计入 E0）","",f"- 初次请求 `{earlier[0]['request_id']}`。引擎记录时限 {details[0]['max_wall_s']} s；登记原因：{earlier[0].get('reason','工程失败')}。",
            f"- 延长请求 `{failed['request_id']}`。最后资源采样 {details[1]['last_wall_sample_s']:.3f} s，登记时限 {details[1]['max_wall_s']} s；MCP 状态为 failed，引擎未确认完成。"+
            ("收尾移动日志时还报告 WinError 32 文件句柄占用。" if 'WinError 32' in failed.get('reason','') else str(failed.get('reason','工程失败'))),
            f"- 两车最后完整控制 tick 为 {diag['last_control_tick_s']} s。密度 {dens} 的 seed {job[2]} 未验收，后续同密度未启动的种子不产生观测值。"]
    if all(x["expected"]==x["observed"] for x in diagnostic):
        vals=[x["cbr"] for x in diagnostic]; post=[x["feedback_fraction"] for x in diagnostic if x["start_s"]>=job[1]]
        lines.append(f"- 仅供工程排查，a02 两辆目标车各有 50、50、300、300、300 个完整 0.1 s 窗；10 个单车窗口均值范围 {100*min(vals):.3f}%–{100*max(vals):.3f}%，长窗分段的调率时长占比范围 {100*min(post):.2f}%–{100*max(post):.2f}%。此条来自未验收的单个种子，未参加图表、可实现范围或档位判定。")
    lines+=["- 真实完整性和两个种子都是科学判定的先决条件。若继续，应以独立版本登记新的预算、估算及停止条件，再复核完整的 120 s 运行。"]
    note.write_text("\n".join(lines)+"\n",encoding="utf-8")
    csv_path=out/"candidate_decisions.csv"; records=list(ev.cols(csv_path))
    for r in records:
        if int(r["density"])==dens and r["status"]!="几何排除":
            r["status"]="工程阻塞；该密度未闭合";r["reason"]=f"seed {job[2]} 原始与唯一延长尝试均失败；未验收种子 {missing}"
    ev.dump_csv(csv_path,records)
    verification.update(complete=False,engineering_terminal=True,status=label,scientific_decision=d["status"],missing_seeds_at_density=missing,
                        blocked_job=job,failed_attempts=details,excluded_partial_diagnostic=diag,registered_wall_budget_s=ext.get("new_wall_timeout_s"))
    verification["output_sha256"][note.name]=ev.sha(note)
    verification["output_sha256"][csv_path.name]=ev.sha(csv_path)
    ev.put(out/"verification.json",verification)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project",type=Path,required=True);parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--request-id",required=True)
    parser.add_argument("--frozen-index-root",type=Path)
    a=parser.parse_args();close(a.project,a.out,a.request_id,a.frozen_index_root)
